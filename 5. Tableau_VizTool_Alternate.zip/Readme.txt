1. To open visualization dashboard using tableau desktop (x64)

a. Please install tableau desktop software to your PC from this site (14 trial period) or install tableau from UALR software site

https://www.tableau.com/products/desktop/download

b. Download tableau virtualization affordability dashboard packaged file to your PC desktop
Affordability 2025v3-packaged.twbx

c. Open tableau desktop and then click on File>Open>Affordability 2025v3-packaged.twbx


2. Viewing Tableau virtualization dashboard on Tableau Public

Note: The tableau dashboard is published to Tableau public portal.

a. please open a browser session

b. please enter URL and press enter to view tableau dashboard on tableau public
https://public.tableau.com/app/profile/chandrasekaran.ramanathan/viz/Affordability2024v2/Affordability?publish=yes